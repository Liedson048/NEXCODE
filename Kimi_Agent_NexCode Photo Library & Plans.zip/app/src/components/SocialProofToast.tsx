import { useState, useEffect } from 'react';
import { MapPin, Clock } from 'lucide-react';

interface Notification {
  name: string;
  initials: string;
  action: string;
  location: string;
  time: string;
}

const notifications: Notification[] = [
  { name: 'João Silva', initials: 'JS', action: 'contratou o plano BUSINESS', location: 'São Paulo, SP', time: 'há 2 minutos' },
  { name: 'Maria Santos', initials: 'MS', action: 'solicitou orçamento', location: 'Rio de Janeiro, RJ', time: 'há 5 minutos' },
  { name: 'Pedro Costa', initials: 'PC', action: 'contratou o plano STARTER', location: 'Belo Horizonte, MG', time: 'há 8 minutos' },
  { name: 'Ana Paula', initials: 'AP', action: 'agendou uma demonstração', location: 'Curitiba, PR', time: 'há 12 minutos' },
  { name: 'Carlos Mendes', initials: 'CM', action: 'contratou o plano ENTERPRISE', location: 'Brasília, DF', time: 'há 15 minutos' },
  { name: 'Fernanda Lima', initials: 'FL', action: 'solicitou template personalizado', location: 'Porto Alegre, RS', time: 'há 18 minutos' },
  { name: 'Ricardo Souza', initials: 'RS', action: 'contratou o plano BUSINESS', location: 'Salvador, BA', time: 'há 22 minutos' },
  { name: 'Juliana Martins', initials: 'JM', action: 'fez upgrade para ENTERPRISE', location: 'Fortaleza, CE', time: 'há 25 minutos' },
];

export function SocialProofToast() {
  const [currentNotification, setCurrentNotification] = useState<Notification | null>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Show first notification after 5 seconds
    const initialTimeout = setTimeout(() => {
      showRandomNotification();
    }, 5000);

    return () => clearTimeout(initialTimeout);
  }, []);

  const showRandomNotification = () => {
    const randomNotification = notifications[Math.floor(Math.random() * notifications.length)];
    setCurrentNotification(randomNotification);
    setIsVisible(true);

    // Hide after 5 seconds
    setTimeout(() => {
      setIsVisible(false);
    }, 5000);

    // Show next notification after random interval (10-20 seconds)
    const nextInterval = Math.random() * 10000 + 10000;
    setTimeout(() => {
      showRandomNotification();
    }, nextInterval);
  };

  if (!currentNotification) return null;

  return (
    <div
      className={`fixed bottom-4 left-4 z-50 transform transition-transform duration-500 ${
        isVisible ? 'translate-x-0' : '-translate-x-[calc(100%+20px)]'
      }`}
    >
      <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-4 max-w-sm shadow-2xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-white to-gray-300 flex items-center justify-center text-black text-sm font-bold">
            {currentNotification.initials}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-white truncate">{currentNotification.name}</p>
            <p className="text-xs text-gray-400">{currentNotification.action}</p>
            <div className="flex items-center gap-2 mt-1">
              <MapPin className="w-3 h-3 text-gray-500" />
              <span className="text-xs text-gray-500">{currentNotification.location}</span>
              <span className="text-gray-600">•</span>
              <Clock className="w-3 h-3 text-gray-500" />
              <span className="text-xs text-gray-500">{currentNotification.time}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
