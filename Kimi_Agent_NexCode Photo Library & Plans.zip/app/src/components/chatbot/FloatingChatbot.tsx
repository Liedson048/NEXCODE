import { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, User, Sparkles } from 'lucide-react';

interface Message {
  id: number;
  text: string;
  sender: 'bot' | 'user';
  timestamp: Date;
}

const quickReplies = [
  'Quanto custa?',
  'Como funciona?',
  'Ver templates',
  'Falar com humano',
];

const botResponses: Record<string, string> = {
  'quanto custa?': 'Temos planos a partir de R$ 297! 🎉\n\n• Starter: R$ 297 (site + IA básica)\n• Business: R$ 497 (site + IA avançada + CRM)\n• Enterprise: R$ 997 (tudo + personalizado)\n\nQual você quer conhecer melhor?',
  'como funciona?': 'É super simples! ⚡\n\n1️⃣ Escolha seu template\n2️⃣ Personalizamos com sua marca\n3️⃣ Configuramos a IA do WhatsApp\n4️⃣ Seu site fica no ar em 7 dias!\n\nQuer ver um exemplo ao vivo?',
  'ver templates': 'Temos templates para diversos segmentos! 🎨\n\n• Salões de beleza\n• Clínicas médicas\n• Restaurantes\n• Lojas virtuais\n• Serviços profissionais\n\nRole a página para ver nossa galeria completa! 👇',
  'falar com humano': 'Claro! Vou conectar você com um especialista. 👨‍💼\n\nVocê pode:\n• WhatsApp: (11) 99999-9999\n• Email: contato@nexcode.com.br\n• Agendar call: nexcode.com.br/call\n\nEstamos online de segunda a sexta, 9h às 18h!',
  'default': 'Ótima pergunta! 🤔\n\nPosso te ajudar com:\n• Informações sobre planos e preços\n• Como funciona nosso serviço\n• Ver exemplos de templates\n• Falar com um especialista\n\nO que você prefere?',
};

export function FloatingChatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: 'Olá! Sou o assistente virtual da NexCode! 🤖✨\n\nComo posso ajudar você hoje?',
      sender: 'bot',
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 300);
    }
  }, [isOpen]);

  const handleSendMessage = (text: string) => {
    if (!text.trim()) return;

    const userMessage: Message = {
      id: Date.now(),
      text,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate bot typing delay
    setTimeout(() => {
      const lowerText = text.toLowerCase();
      let responseText = botResponses.default;

      for (const [key, value] of Object.entries(botResponses)) {
        if (lowerText.includes(key)) {
          responseText = value;
          break;
        }
      }

      const botMessage: Message = {
        id: Date.now() + 1,
        text: responseText,
        sender: 'bot',
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, botMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const handleQuickReply = (reply: string) => {
    handleSendMessage(reply);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage(inputValue);
    }
  };

  return (
    <div className="chatbot-container">
      {/* Chat Window */}
      <div className={`chatbot-window ${isOpen ? 'open' : ''}`}>
        {/* Header */}
        <div className="chatbot-header">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-white to-gray-300 flex items-center justify-center">
                <Bot className="w-5 h-5 text-black" />
              </div>
              <div>
                <h4 className="font-semibold text-white">NexBot</h4>
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-green-500 pulse-dot"></span>
                  <span className="text-xs text-gray-400">Online agora</span>
                </div>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="chatbot-messages flex flex-col gap-3">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-2 ${message.sender === 'user' ? 'flex-row-reverse' : ''}`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  message.sender === 'bot'
                    ? 'bg-gradient-to-br from-white to-gray-300'
                    : 'bg-white/10'
                }`}
              >
                {message.sender === 'bot' ? (
                  <Bot className="w-4 h-4 text-black" />
                ) : (
                  <User className="w-4 h-4 text-white" />
                )}
              </div>
              <div
                className={`message-bubble ${message.sender}`}
                style={{ whiteSpace: 'pre-line' }}
              >
                {message.text}
              </div>
            </div>
          ))}

          {/* Quick Replies */}
          {messages[messages.length - 1]?.sender === 'bot' && !isTyping && (
            <div className="flex flex-wrap gap-1 mt-2 ml-10">
              {quickReplies.map((reply) => (
                <button
                  key={reply}
                  onClick={() => handleQuickReply(reply)}
                  className="quick-reply"
                >
                  {reply}
                </button>
              ))}
            </div>
          )}

          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex gap-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-white to-gray-300 flex items-center justify-center">
                <Bot className="w-4 h-4 text-black" />
              </div>
              <div className="message-bubble bot typing-indicator flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-white/50"></span>
                <span className="w-2 h-2 rounded-full bg-white/50"></span>
                <span className="w-2 h-2 rounded-full bg-white/50"></span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="chatbot-input-area">
          <input
            ref={inputRef}
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Digite sua mensagem..."
            className="flex-1 bg-white/5 border border-white/10 rounded-full px-4 py-2 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-white/30 transition-colors"
          />
          <button
            onClick={() => handleSendMessage(inputValue)}
            disabled={!inputValue.trim()}
            className="w-10 h-10 rounded-full bg-white flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed hover:scale-105 transition-transform"
          >
            <Send className="w-4 h-4 text-black" />
          </button>
        </div>
      </div>

      {/* Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="chatbot-button"
      >
        {isOpen ? (
          <X className="w-6 h-6" />
        ) : (
          <div className="relative">
            <MessageCircle className="w-6 h-6" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-white"></span>
          </div>
        )}
      </button>

      {/* Notification Badge when closed */}
      {!isOpen && messages.length <= 1 && (
        <div className="absolute -top-2 -left-2 bg-white text-black text-xs font-bold px-2 py-1 rounded-full flex items-center gap-1 animate-bounce">
          <Sparkles className="w-3 h-3" />
          Novo!
        </div>
      )}
    </div>
  );
}
