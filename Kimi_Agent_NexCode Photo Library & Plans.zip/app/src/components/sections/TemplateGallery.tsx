import { useState, useEffect } from 'react';
import { ExternalLink, Eye, Check, Star, ArrowRight, Search, X } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface Template {
  id: number;
  name: string;
  category: string;
  image: string;
  description: string;
  features: string[];
  price: string;
  popular?: boolean;
  new?: boolean;
  demoUrl: string;
}

const categories = [
  { id: 'all', name: 'Todos', count: 6 },
  { id: 'food', name: 'Gastronomia', count: 1 },
  { id: 'beauty', name: 'Beleza & Estética', count: 2 },
  { id: 'retail', name: 'Lojas & E-commerce', count: 2 },
  { id: 'automotive', name: 'Automotivo', count: 1 },
];

const templates: Template[] = [
  {
    id: 1,
    name: 'Spezza Pizza',
    category: 'food',
    image: '/templates/ChatGPT Image 19 de fev. de 2026, 18_55_11.png',
    description: 'Template completo para pizzarias e hamburguerias com sistema de delivery, carrinho de compras e pagamento integrado. Design moderno e escuro que valoriza seus produtos.',
    features: ['Cardápio digital', 'Carrinho de compras', 'Pagamento online', 'Rastreamento de pedido', 'Área do cliente', 'Cupons de desconto'],
    price: 'R$ 299,99',
    popular: true,
    demoUrl: '#',
  },
  {
    id: 2,
    name: 'Esmalteria Bella',
    category: 'beauty',
    image: '/templates/ChatGPT Image 19 de fev. de 2026, 18_43_40.png',
    description: 'Template elegante para esmalterias e salões de beleza. Sistema completo de agendamento online, painel administrativo e gestão de clientes em tons rosados delicados.',
    features: ['Agendamento online', 'Painel administrativo', 'Gestão de clientes', 'Catálogo de serviços', 'Loja de produtos', 'Lembretes automáticos'],
    price: 'R$ 299,99',
    demoUrl: '#',
  },
  {
    id: 3,
    name: 'AutoParts',
    category: 'automotive',
    image: '/templates/ChatGPT Image 19 de fev. de 2026, 18_41_18.png',
    description: 'Template robusto para lojas de peças automotivas e auto centers. Design profissional com busca avançada, categorias de produtos e checkout completo.',
    features: ['Busca avançada de peças', 'Categorias por sistema', 'Carrinho de compras', 'Múltiplos endereços', 'Formas de pagamento', 'Área do cliente'],
    price: 'R$ 299,99',
    new: true,
    demoUrl: '#',
  },
  {
    id: 4,
    name: 'Mercado Fácil',
    category: 'retail',
    image: '/templates/ChatGPT Image 19 de fev. de 2026, 18_38_45.png',
    description: 'Template completo para supermercados e mercados online. Sistema de delivery com categorias organizadas, carrinho inteligente e checkout otimizado.',
    features: ['Categorias de produtos', 'Carrinho inteligente', 'Delivery integrado', 'Múltiplos endereços', 'Programa de fidelidade', 'Ofertas da semana'],
    price: 'R$ 299,99',
    popular: true,
    demoUrl: '#',
  },
  {
    id: 5,
    name: 'Beauty Spa',
    category: 'beauty',
    image: '/templates/ChatGPT Image 19 de fev. de 2026, 18_36_04.png',
    description: 'Template sofisticado para spas, clínicas de estética e centros de bem-estar. Design luxuoso com sistema de agendamento e gestão completa de serviços.',
    features: ['Agendamento por serviço', 'Escolha de profissional', 'Painel administrativo', 'Histórico de atendimentos', 'Pacotes promocionais', 'Gift cards'],
    price: 'R$ 299,99',
    new: true,
    demoUrl: '#',
  },
  {
    id: 6,
    name: 'TechStore',
    category: 'retail',
    image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&h=400&fit=crop',
    description: 'Template moderno para lojas de eletrônicos, celulares e produtos tecnológicos. Design clean com comparação de produtos e avaliações.',
    features: ['Comparação de produtos', 'Avaliações de clientes', 'Carrinho de compras', 'Filtros avançados', 'Lista de desejos', 'Notificações de estoque'],
    price: 'R$ 299,99',
    demoUrl: '#',
  },
];

export function TemplateGallery() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [showSearch, setShowSearch] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const section = document.getElementById('templates');
    if (section) {
      observer.observe(section);
    }

    return () => observer.disconnect();
  }, []);

  const filteredTemplates = templates.filter((template) => {
    const matchesCategory = activeCategory === 'all' || template.category === activeCategory;
    const matchesSearch = template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <section id="templates" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className={`text-center mb-16 fade-in ${isVisible ? 'visible' : ''}`}>
          <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-4 py-2 mb-6">
            <Star className="w-4 h-4 text-white" />
            <span className="text-sm text-gray-300">Biblioteca de Templates</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="gradient-text">Escolha seu template</span>
            <br />
            <span className="text-white">e personalize</span>
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Templates profissionais prontos para diversos segmentos. 
            Escolha, personalize e tenha seu site no ar em até 7 dias úteis.
          </p>
        </div>

        {/* Search and Filter Bar */}
        <div className={`flex flex-col md:flex-row gap-4 mb-10 fade-in ${isVisible ? 'visible' : ''}`}>
          {/* Category Filters */}
          <div className="flex-1 flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`category-filter ${activeCategory === category.id ? 'active' : ''}`}
              >
                {category.name}
                <span className="ml-2 text-xs opacity-60">({category.count})</span>
              </button>
            ))}
          </div>

          {/* Search */}
          <div className="relative">
            {showSearch ? (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Buscar templates..."
                  className="bg-white/5 border border-white/10 rounded-full px-4 py-2 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-white/30 w-64"
                  autoFocus
                />
                <button
                  onClick={() => {
                    setShowSearch(false);
                    setSearchQuery('');
                  }}
                  className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowSearch(true)}
                className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors"
              >
                <Search className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Templates Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTemplates.map((template, index) => (
            <div
              key={template.id}
              className={`template-card bg-white/5 border border-white/10 rounded-2xl overflow-hidden cursor-pointer fade-in ${isVisible ? 'visible' : ''}`}
              style={{ transitionDelay: `${index * 100}ms` }}
              onClick={() => setSelectedTemplate(template)}
            >
              {/* Image */}
              <div className="relative h-56 overflow-hidden">
                <img
                  src={template.image}
                  alt={template.name}
                  className="template-image w-full h-full object-cover object-top"
                />
                <div className="template-overlay absolute inset-0 flex items-end p-4">
                  <button className="flex items-center gap-2 bg-white text-black px-4 py-2 rounded-full text-sm font-semibold hover:scale-105 transition-transform">
                    <Eye className="w-4 h-4" />
                    Ver detalhes
                  </button>
                </div>
                
                {/* Badges */}
                <div className="absolute top-3 left-3 flex gap-2">
                  {template.popular && (
                    <span className="bg-white text-black text-xs font-bold px-2 py-1 rounded-full flex items-center gap-1">
                      <Star className="w-3 h-3" />
                      Popular
                    </span>
                  )}
                  {template.new && (
                    <span className="bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                      Novo
                    </span>
                  )}
                </div>
              </div>

              {/* Content */}
              <div className="p-5">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="text-lg font-semibold text-white">{template.name}</h3>
                  <span className="text-sm font-bold text-white">{template.price}</span>
                </div>
                <p className="text-sm text-gray-400 mb-4 line-clamp-2">{template.description}</p>
                
                {/* Features Preview */}
                <div className="flex flex-wrap gap-1.5">
                  {template.features.slice(0, 3).map((feature, i) => (
                    <span
                      key={i}
                      className="text-xs bg-white/5 text-gray-300 px-2 py-1 rounded-full"
                    >
                      {feature}
                    </span>
                  ))}
                  {template.features.length > 3 && (
                    <span className="text-xs bg-white/5 text-gray-300 px-2 py-1 rounded-full">
                      +{template.features.length - 3}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {filteredTemplates.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-gray-500" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Nenhum template encontrado</h3>
            <p className="text-gray-400">Tente buscar com outros termos ou categoria</p>
          </div>
        )}

        {/* CTA */}
        <div className={`text-center mt-12 fade-in ${isVisible ? 'visible' : ''}`}>
          <p className="text-gray-400 mb-4">Não encontrou o que procura?</p>
          <button className="btn-outline px-6 py-3 rounded-full font-semibold inline-flex items-center gap-2">
            Solicitar template personalizado
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Template Detail Modal */}
      <Dialog open={!!selectedTemplate} onOpenChange={() => setSelectedTemplate(null)}>
        <DialogContent className="max-w-4xl bg-[#0a0a0a] border-white/10 text-white max-h-[90vh] overflow-y-auto">
          {selectedTemplate && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl font-bold flex items-center gap-3">
                  {selectedTemplate.name}
                  {selectedTemplate.popular && (
                    <span className="bg-white text-black text-xs font-bold px-2 py-1 rounded-full flex items-center gap-1">
                      <Star className="w-3 h-3" />
                      Popular
                    </span>
                  )}
                </DialogTitle>
              </DialogHeader>

              <div className="grid md:grid-cols-2 gap-6 mt-4">
                {/* Image */}
                <div className="rounded-xl overflow-hidden">
                  <img
                    src={selectedTemplate.image}
                    alt={selectedTemplate.name}
                    className="w-full h-64 md:h-full object-cover object-top"
                  />
                </div>

                {/* Details */}
                <div>
                  <p className="text-gray-400 mb-6">{selectedTemplate.description}</p>

                  {/* Features */}
                  <div className="mb-6">
                    <h4 className="font-semibold mb-3">Recursos inclusos:</h4>
                    <ul className="space-y-2">
                      {selectedTemplate.features.map((feature, i) => (
                        <li key={i} className="flex items-center gap-2 text-sm text-gray-300">
                          <Check className="w-4 h-4 text-green-500" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Price */}
                  <div className="bg-white/5 rounded-xl p-4 mb-6">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Investimento</span>
                      <span className="text-2xl font-bold">{selectedTemplate.price}</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">+ mensalidade a partir de R$ 99,99</p>
                    <p className="text-xs text-green-400 mt-1">✓ Domínio grátis por 1 ano</p>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-3">
                    <button className="btn-primary flex-1 py-3 rounded-full font-semibold flex items-center justify-center gap-2">
                      Quero este template
                      <ArrowRight className="w-4 h-4" />
                    </button>
                    <button className="btn-outline px-4 py-3 rounded-full flex items-center gap-2">
                      <ExternalLink className="w-4 h-4" />
                      Demo
                    </button>
                  </div>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
