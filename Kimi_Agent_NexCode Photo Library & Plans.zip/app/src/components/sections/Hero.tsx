import { useState, useEffect } from 'react';
import { ArrowRight, Play, ChevronDown, Clock, Zap, Shield, Globe } from 'lucide-react';

export function Hero() {
  const [timeLeft, setTimeLeft] = useState({ hours: 23, minutes: 59, seconds: 59 });
  const [typingText, setTypingText] = useState('');
  const fullText = 'WhatsApp';
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
    
    // Countdown timer
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        let { hours, minutes, seconds } = prev;
        seconds--;
        if (seconds < 0) {
          seconds = 59;
          minutes--;
        }
        if (minutes < 0) {
          minutes = 59;
          hours--;
        }
        if (hours < 0) {
          hours = 23;
          minutes = 59;
          seconds = 59;
        }
        return { hours, minutes, seconds };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Typing effect
  useEffect(() => {
    let index = 0;
    const typingInterval = setInterval(() => {
      if (index <= fullText.length) {
        setTypingText(fullText.slice(0, index));
        index++;
      } else {
        setTimeout(() => {
          index = 0;
          setTypingText('');
        }, 2000);
      }
    }, 200);

    return () => clearInterval(typingInterval);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 grid-pattern opacity-30"></div>
      <div className="absolute inset-0 hero-gradient"></div>
      <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-white/5 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-white/3 rounded-full blur-3xl animate-pulse delay-1000"></div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className={`fade-in ${isVisible ? 'visible' : ''}`}>
          {/* Countdown Offer */}
          <div className="inline-block mb-8">
            <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-6 py-4">
              <p className="text-red-400 font-semibold mb-2 text-sm uppercase tracking-wider flex items-center justify-center gap-2">
                <span className="animate-pulse">🔥</span>
                Oferta de Lançamento
              </p>
              <div className="flex justify-center gap-3 text-2xl font-bold">
                <div className="bg-white/5 rounded-lg px-4 py-2 border border-white/10 flex flex-col items-center min-w-[70px]">
                  <span className="text-3xl">{String(timeLeft.hours).padStart(2, '0')}</span>
                  <span className="text-xs text-gray-500 font-normal">horas</span>
                </div>
                <div className="bg-white/5 rounded-lg px-4 py-2 border border-white/10 flex flex-col items-center min-w-[70px]">
                  <span className="text-3xl">{String(timeLeft.minutes).padStart(2, '0')}</span>
                  <span className="text-xs text-gray-500 font-normal">min</span>
                </div>
                <div className="bg-white/5 rounded-lg px-4 py-2 border border-white/10 flex flex-col items-center min-w-[70px]">
                  <span className="text-3xl">{String(timeLeft.seconds).padStart(2, '0')}</span>
                  <span className="text-xs text-gray-500 font-normal">seg</span>
                </div>
              </div>
              <p className="text-xs text-gray-400 mt-2">Preços promocionais por tempo limitado</p>
            </div>
          </div>

          {/* Main Headline */}
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight mb-6 leading-tight">
            <span className="gradient-text">Site Profissional</span>
            <br />
            <span className="text-white">+ IA no</span>
            <br />
            <span className="gradient-text typing-effect">{typingText}</span>
          </h1>

          <p className="mt-6 text-xl md:text-2xl text-gray-400 max-w-3xl mx-auto leading-relaxed">
            Tenha uma <span className="text-white font-semibold">presença digital de verdade</span> e
            <span className="text-white font-semibold"> venda no automático</span> com nossa IA integrada ao WhatsApp.
            A partir de <span className="text-white font-bold">R$ 299,99</span>.
          </p>

          {/* CTA Buttons */}
          <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button
              onClick={() => scrollToSection('planos')}
              className="btn-primary px-8 py-4 rounded-full text-lg font-semibold flex items-center gap-2 group"
            >
              Quero Meu Site Agora
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={() => scrollToSection('templates')}
              className="btn-outline px-8 py-4 rounded-full text-lg font-semibold flex items-center gap-2"
            >
              <Play className="w-5 h-5" />
              Ver Templates
            </button>
          </div>

          {/* Trust Badges */}
          <div className="mt-12 flex flex-wrap justify-center gap-6">
            <div className="flex items-center gap-2 text-sm text-gray-400">
              <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center">
                <Shield className="w-4 h-4 text-green-400" />
              </div>
              <span>7 dias de garantia</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-400">
              <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center">
                <Clock className="w-4 h-4 text-blue-400" />
              </div>
              <span>Entrega em até 7 dias</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-400">
              <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center">
                <Globe className="w-4 h-4 text-purple-400" />
              </div>
              <span>Domínio grátis 1 ano</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-400">
              <div className="w-8 h-8 rounded-full bg-yellow-500/20 flex items-center justify-center">
                <Zap className="w-4 h-4 text-yellow-400" />
              </div>
              <span>Sem taxa de setup</span>
            </div>
          </div>

          {/* Trust Indicators */}
          <div className="mt-16 pt-8 border-t border-white/10">
            <p className="text-sm text-gray-500 mb-6">Já ajudamos +200 pequenos negócios a crescerem online</p>
            <div className="flex flex-wrap justify-center gap-8 opacity-50">
              {['Bella Estética', 'Tech Imports', 'Padaria Real', 'Clínica Vida', 'Mecânica Silva'].map((brand) => (
                <span key={brand} className="text-lg font-semibold text-gray-400">{brand}</span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ChevronDown className="w-6 h-6 text-white/50" />
      </div>
    </section>
  );
}
