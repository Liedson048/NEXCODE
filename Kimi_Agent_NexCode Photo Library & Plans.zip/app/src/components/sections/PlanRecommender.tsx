import { useState, useEffect, useRef } from 'react';
import { Sparkles, Send, Loader2, Check, Bot, Lightbulb, ArrowRight, X } from 'lucide-react';

interface Recommendation {
  plan: 'basic' | 'pro' | 'premium';
  confidence: number;
  reasons: string[];
}

const planDetails = {
  basic: {
    name: 'Basic',
    price: 'R$ 299,99',
    monthlyFee: 'R$ 99,99/mês',
    color: 'from-blue-500/20 to-blue-600/10',
    borderColor: 'border-blue-500/30',
    features: ['Até 3 páginas', 'Template da biblioteca', 'IA básica', 'Suporte comercial'],
  },
  pro: {
    name: 'Pro',
    price: 'R$ 499,99',
    monthlyFee: 'R$ 149,99/mês',
    color: 'from-purple-500/20 to-purple-600/10',
    borderColor: 'border-purple-500/30',
    features: ['Até 7 páginas', 'Qualquer template', 'IA avançada', 'Suporte prioritário'],
  },
  premium: {
    name: 'Premium',
    price: 'R$ 899,99',
    monthlyFee: 'R$ 249,99/mês',
    color: 'from-amber-500/20 to-amber-600/10',
    borderColor: 'border-amber-500/30',
    features: ['Páginas ilimitadas', 'Template personalizado', 'IA premium', 'Suporte 24/7'],
  },
};

// Keywords para análise
const keywords = {
  basic: [
    'pequeno', 'iniciando', 'começando', 'simples', 'básico', 'básica',
    'poucos', 'poucas', 'inicio', 'inicial', 'barato', 'economico',
    '10 clientes', '20 clientes', 'pouco movimento', 'salao pequeno',
    'consultorio pequeno', 'loja pequena', 'so pra começar',
  ],
  pro: [
    'crescendo', 'médio', 'media', 'moderado', 'bom', 'boa',
    'varios', 'várias', 'diversos', 'diversas', 'profissional',
    '50 clientes', '100 clientes', 'movimento moderado', 'clinica',
    'restaurante', 'loja virtual', 'ecommerce pequeno', 'varios servicos',
    'varias paginas', 'mais de 3 paginas', 'blog', 'portfolio',
  ],
  premium: [
    'grande', 'empresa', 'corporativo', 'corporativa', 'completo',
    'completa', 'total', 'ilimitado', 'ilimitada', 'personalizado',
    'personalizada', 'unico', 'única', 'exclusivo', 'exclusiva',
    '200 clientes', '500 clientes', 'muito movimento', 'franquia',
    'rede', 'varias unidades', 'ecommerce grande', 'marketplace',
    'sistema complexo', 'integracao', 'api', 'personalizado do zero',
  ],
};

function analyzeProject(description: string): Recommendation {
  const lowerDesc = description.toLowerCase();
  
  let basicScore = 0;
  let proScore = 0;
  let premiumScore = 0;
  const matchedReasons: string[] = [];

  // Contar matches para cada plano
  keywords.basic.forEach(keyword => {
    if (lowerDesc.includes(keyword)) {
      basicScore++;
      if (!matchedReasons.includes('Projeto de pequeno porte')) {
        matchedReasons.push('Projeto de pequeno porte');
      }
    }
  });

  keywords.pro.forEach(keyword => {
    if (lowerDesc.includes(keyword)) {
      proScore++;
      if (!matchedReasons.includes('Necessidades moderadas de crescimento')) {
        matchedReasons.push('Necessidades moderadas de crescimento');
      }
    }
  });

  keywords.premium.forEach(keyword => {
    if (lowerDesc.includes(keyword)) {
      premiumScore++;
      if (!matchedReasons.includes('Alto volume e complexidade')) {
        matchedReasons.push('Alto volume e complexidade');
      }
    }
  });

  // Análise adicional baseada em padrões
  if (lowerDesc.includes('pagina') || lowerDesc.includes('página')) {
    const pageMatch = lowerDesc.match(/(\d+)\s*p[áa]ginas?/);
    if (pageMatch) {
      const pages = parseInt(pageMatch[1]);
      if (pages <= 3) {
        basicScore += 2;
        matchedReasons.push(`Projeto com ${pages} página(s) - ideal para Basic`);
      } else if (pages <= 7) {
        proScore += 2;
        matchedReasons.push(`Projeto com ${pages} páginas - recomendado Pro`);
      } else {
        premiumScore += 3;
        matchedReasons.push(`Projeto com ${pages} páginas - necessita Premium`);
      }
    }
  }

  if (lowerDesc.includes('cliente') || lowerDesc.includes('paciente')) {
    const clientMatch = lowerDesc.match(/(\d+)\s*(clientes?|pacientes?)/);
    if (clientMatch) {
      const clients = parseInt(clientMatch[1]);
      if (clients <= 20) {
        basicScore += 1;
      } else if (clients <= 100) {
        proScore += 2;
        matchedReasons.push(`Volume de ${clients} clientes - Pro recomendado`);
      } else {
        premiumScore += 3;
        matchedReasons.push(`Alto volume de ${clients} clientes - Premium ideal`);
      }
    }
  }

  if (lowerDesc.includes('personalizado') || lowerDesc.includes('único') || lowerDesc.includes('exclusivo')) {
    premiumScore += 3;
    matchedReasons.push('Necessidade de design personalizado');
  }

  if (lowerDesc.includes('24h') || lowerDesc.includes('24 horas') || lowerDesc.includes('urgente')) {
    premiumScore += 2;
    matchedReasons.push('Necessidade de suporte 24/7');
  }

  // Determinar vencedor
  let recommendedPlan: 'basic' | 'pro' | 'premium' = 'basic';
  let maxScore = basicScore;

  if (proScore > maxScore) {
    recommendedPlan = 'pro';
    maxScore = proScore;
  }
  if (premiumScore > maxScore) {
    recommendedPlan = 'premium';
    maxScore = premiumScore;
  }

  // Se não encontrou nenhuma keyword específica, analisar tamanho do texto
  if (maxScore === 0) {
    if (description.length < 50) {
      recommendedPlan = 'basic';
      matchedReasons.push('Projeto descrito de forma simples');
    } else if (description.length < 150) {
      recommendedPlan = 'pro';
      matchedReasons.push('Projeto com necessidades moderadas');
    } else {
      recommendedPlan = 'premium';
      matchedReasons.push('Projeto complexo e detalhado');
    }
  }

  // Calcular confiança
  const totalScore = basicScore + proScore + premiumScore;
  const confidence = totalScore > 0 ? Math.round((maxScore / totalScore) * 100) : 70;

  // Adicionar razões padrão se não tiver nenhuma
  if (matchedReasons.length === 0) {
    if (recommendedPlan === 'basic') {
      matchedReasons.push('Ideal para quem está começando');
    } else if (recommendedPlan === 'pro') {
      matchedReasons.push('Perfeito para negócios em crescimento');
    } else {
      matchedReasons.push('Recomendado para empresas estabelecidas');
    }
  }

  return {
    plan: recommendedPlan,
    confidence: Math.min(confidence + 20, 95), // Ajuste para não ficar muito baixo
    reasons: matchedReasons.slice(0, 3), // Máximo 3 razões
  };
}

export function PlanRecommender() {
  const [description, setDescription] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [recommendation, setRecommendation] = useState<Recommendation | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const section = document.getElementById('recomendador');
    if (section) {
      observer.observe(section);
    }

    return () => observer.disconnect();
  }, []);

  const handleAnalyze = async () => {
    if (!description.trim()) return;

    setIsAnalyzing(true);
    setShowResult(false);

    // Simular delay de análise da IA
    await new Promise(resolve => setTimeout(resolve, 2000));

    const result = analyzeProject(description);
    setRecommendation(result);
    setIsAnalyzing(false);
    setShowResult(true);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && e.metaKey) {
      handleAnalyze();
    }
  };

  const scrollToPlans = () => {
    const element = document.getElementById('planos');
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="recomendador" className="py-24 relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className={`text-center mb-12 fade-in ${isVisible ? 'visible' : ''}`}>
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-500/20 to-blue-500/20 border border-purple-500/30 rounded-full px-4 py-2 mb-6">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-gray-300">IA Recomendadora</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="gradient-text">Não sabe qual plano escolher?</span>
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Descreva o que você espera do seu projeto e nossa IA vai analisar e indicar 
            a melhor opção para você.
          </p>
        </div>

        {/* Input Area */}
        <div className={`fade-in ${isVisible ? 'visible' : ''}`}>
          <div className="bg-white/5 border border-white/10 rounded-3xl p-6 md:p-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-semibold">Assistente NexCode</h3>
                <p className="text-sm text-gray-400">Vou analisar seu projeto e recomendar o plano ideal</p>
              </div>
            </div>

            <div className="relative">
              <textarea
                ref={textareaRef}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ex: Tenho um salão de beleza pequeno, atendo cerca de 15 clientes por dia. Preciso de um site para agendamento online e mostrar meus serviços de manicure e cabelereiro..."
                className="w-full h-40 bg-black/30 border border-white/10 rounded-2xl p-4 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500/50 resize-none transition-colors"
                disabled={isAnalyzing}
              />
              <div className="absolute bottom-4 right-4 text-xs text-gray-500">
                {description.length} caracteres
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 mt-6">
              <button
                onClick={handleAnalyze}
                disabled={!description.trim() || isAnalyzing}
                className="btn-primary flex-1 py-4 rounded-full font-semibold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Analisando seu projeto...
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    Analisar meu projeto
                  </>
                )}
              </button>
              {showResult && (
                <button
                  onClick={() => {
                    setDescription('');
                    setShowResult(false);
                    setRecommendation(null);
                    textareaRef.current?.focus();
                  }}
                  className="btn-outline px-6 py-4 rounded-full font-semibold flex items-center justify-center gap-2"
                >
                  <X className="w-5 h-5" />
                  Nova análise
                </button>
              )}
            </div>

            <p className="text-xs text-gray-500 mt-4 text-center">
              💡 Dica: Quanto mais detalhes você fornecer, melhor será a recomendação!
            </p>
          </div>
        </div>

        {/* Result */}
        {showResult && recommendation && (
          <div className={`mt-8 fade-in visible`}>
            <div className={`bg-gradient-to-br ${planDetails[recommendation.plan].color} ${planDetails[recommendation.plan].borderColor} border rounded-3xl p-6 md:p-8`}>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                  <Lightbulb className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Plano Recomendado</h3>
                  <p className="text-sm text-gray-400">
                    Confiança da análise: {recommendation.confidence}%
                  </p>
                </div>
              </div>

              <div className="bg-black/30 rounded-2xl p-6 mb-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div>
                    <h4 className="text-3xl font-bold mb-1">
                      Plano {planDetails[recommendation.plan].name}
                    </h4>
                    <p className="text-gray-400">
                      {planDetails[recommendation.plan].price} 
                      <span className="text-sm"> (único)</span>
                    </p>
                    <p className="text-sm text-green-400 mt-1">
                      + {planDetails[recommendation.plan].monthlyFee}
                    </p>
                  </div>
                  <button
                    onClick={scrollToPlans}
                    className="btn-primary px-6 py-3 rounded-full font-semibold flex items-center justify-center gap-2 whitespace-nowrap"
                  >
                    Quero este plano
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="space-y-4">
                <h5 className="font-semibold flex items-center gap-2">
                  <Check className="w-5 h-5 text-green-400" />
                  Por que este plano é ideal para você:
                </h5>
                <ul className="space-y-2">
                  {recommendation.reasons.map((reason, i) => (
                    <li key={i} className="flex items-start gap-3 text-gray-300">
                      <span className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center flex-shrink-0 text-sm">
                        {i + 1}
                      </span>
                      {reason}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-6 pt-6 border-t border-white/10">
                <h5 className="font-semibold mb-3">O que está incluído:</h5>
                <div className="flex flex-wrap gap-2">
                  {planDetails[recommendation.plan].features.map((feature, i) => (
                    <span
                      key={i}
                      className="bg-white/10 px-3 py-1.5 rounded-full text-sm"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mt-6 p-4 bg-white/5 rounded-xl">
                <p className="text-sm text-gray-400">
                  <strong className="text-white">Lembre-se:</strong> Todos os planos incluem 
                  <span className="text-green-400"> domínio grátis por 1 ano</span>. 
                  Você pode cancelar a mensalidade a qualquer momento sem multa.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Exemplos */}
        {!showResult && (
          <div className={`mt-12 fade-in ${isVisible ? 'visible' : ''}`}>
            <h4 className="text-center text-gray-400 mb-6">Exemplos de descrições</h4>
            <div className="grid md:grid-cols-3 gap-4">
              {[
                {
                  text: '"Sou cabeleireira autônoma, atendo em média 8 clientes por dia. Quero um site simples para mostrar meu trabalho e permitir agendamento."',
                  plan: 'Basic',
                },
                {
                  text: '"Tenho uma clínica de estética com 2 funcionárias. Atendemos cerca de 40 clientes por semana. Preciso de várias páginas de serviços."',
                  plan: 'Pro',
                },
                {
                  text: '"Quero montar uma loja de roupas online com muitos produtos, design único da minha marca e integração com meios de pagamento."',
                  plan: 'Premium',
                },
              ].map((example, i) => (
                <button
                  key={i}
                  onClick={() => setDescription(example.text.replace(/"/g, ''))}
                  className="text-left p-4 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-colors"
                >
                  <p className="text-sm text-gray-400 mb-2 line-clamp-3">{example.text}</p>
                  <span className="text-xs text-purple-400">→ Recomendação: {example.plan}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
