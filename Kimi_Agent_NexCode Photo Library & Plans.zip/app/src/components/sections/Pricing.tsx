import { useEffect, useState } from 'react';
import { Check, X, Star, Sparkles, ArrowRight, HelpCircle, Globe, MessageCircle, Clock, Shield, Zap } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface Plan {
  id: string;
  name: string;
  price: string;
  monthlyFee: string;
  description: string;
  features: { text: string; included: boolean; description?: string }[];
  popular?: boolean;
  cta: string;
  badge?: string;
  icon: React.ElementType;
}

const plans: Plan[] = [
  {
    id: 'basic',
    name: 'Basic',
    price: 'R$ 299,99',
    monthlyFee: 'R$ 99,99/mês',
    description: 'Perfeito para quem está começando',
    badge: 'Mais acessível',
    icon: Shield,
    features: [
      { text: 'Site profissional (até 3 páginas)', included: true, description: 'Home, Sobre, Contato' },
      { text: 'Template da biblioteca', included: true, description: 'Escolha qualquer template disponível' },
      { text: 'IA no WhatsApp', included: true, description: 'Atendimento automático 24h' },
      { text: 'Agendamento online', included: true, description: 'Clientes agendam direto no site' },
      { text: 'Domínio grátis 1 ano', included: true, description: 'Seudominio.com.br incluso' },
      { text: 'Suporte via WhatsApp', included: true, description: 'Atendimento em horário comercial' },
      { text: 'Personalização avançada', included: false },
      { text: 'Relatórios mensais', included: false },
    ],
    cta: 'Começar Agora',
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 'R$ 499,99',
    monthlyFee: 'R$ 149,99/mês',
    description: 'Ideal para negócios em crescimento',
    popular: true,
    badge: 'Mais popular',
    icon: Zap,
    features: [
      { text: 'Site profissional (até 7 páginas)', included: true, description: 'Home, Sobre, Serviços, Portfólio, Blog, Contato, etc.' },
      { text: 'Qualquer template da biblioteca', included: true, description: 'Acesso a todos os templates' },
      { text: 'IA avançada no WhatsApp', included: true, description: 'Mais inteligente e personalizada' },
      { text: 'Agendamento + lembretes', included: true, description: 'Lembretes automáticos por WhatsApp' },
      { text: 'Domínio grátis 1 ano', included: true, description: 'Seudominio.com.br incluso' },
      { text: 'Suporte prioritário', included: true, description: 'Atendimento prioritário via WhatsApp' },
      { text: 'Personalização completa', included: true, description: 'Cores, fontes e layout ajustados' },
      { text: 'Relatórios mensais', included: false },
    ],
    cta: 'Quero Crescer',
  },
  {
    id: 'premium',
    name: 'Premium',
    price: 'R$ 899,99',
    monthlyFee: 'R$ 249,99/mês',
    description: 'Para empresas que precisam de tudo',
    badge: 'Mais completo',
    icon: Star,
    features: [
      { text: 'Site profissional (páginas ilimitadas)', included: true, description: 'Quantas páginas precisar' },
      { text: 'Template personalizado do zero', included: true, description: 'Design único para sua marca' },
      { text: 'IA premium + treinamento', included: true, description: 'IA treinada especificamente para você' },
      { text: 'Sistema completo de agendamento', included: true, description: 'Com gestão de profissionais' },
      { text: 'Domínio grátis 1 ano', included: true, description: 'Seudominio.com.br incluso' },
      { text: 'Suporte 24/7 dedicado', included: true, description: 'Atendimento a qualquer hora' },
      { text: 'Personalização total', included: true, description: 'Tudo feito sob medida' },
      { text: 'Relatórios semanais + BI', included: true, description: 'Análises detalhadas de desempenho' },
    ],
    cta: 'Falar com Especialista',
  },
];

const monthlyFeeDetails = [
  {
    icon: Shield,
    title: 'Manutenções Futuras',
    description: 'Atualizações de segurança, correções de bugs e melhorias contínuas',
  },
  {
    icon: Clock,
    title: 'Ajustes e Alterações',
    description: 'Pequenas mudanças de texto, fotos e informações quando precisar',
  },
  {
    icon: MessageCircle,
    title: 'Suporte via WhatsApp',
    description: 'Tire dúvidas e receba ajuda sempre que precisar',
  },
  {
    icon: Globe,
    title: 'Hospedagem e Domínio',
    description: 'Seu site sempre online com servidor de alta performance',
  },
];

interface PlanDetailsDialogProps {
  plan: Plan | null;
  isOpen: boolean;
  onClose: () => void;
}

function PlanDetailsDialog({ plan, isOpen, onClose }: PlanDetailsDialogProps) {
  if (!plan) return null;

  const PlanIcon = plan.icon;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl bg-[#0a0a0a] border-white/10 text-white max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
              <PlanIcon className="w-5 h-5" />
            </div>
            Plano {plan.name}
            {plan.popular && (
              <span className="bg-white text-black text-xs font-bold px-2 py-1 rounded-full">
                Mais Popular
              </span>
            )}
          </DialogTitle>
        </DialogHeader>

        <div className="mt-4 space-y-6">
          {/* Price Section */}
          <div className="bg-white/5 rounded-2xl p-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <p className="text-gray-400 text-sm mb-1">Investimento único</p>
                <p className="text-3xl font-bold">{plan.price}</p>
              </div>
              <div className="md:text-right">
                <p className="text-gray-400 text-sm mb-1">Mensalidade</p>
                <p className="text-xl font-semibold text-green-400">{plan.monthlyFee}</p>
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-white/10">
              <p className="text-sm text-green-400 flex items-center gap-2">
                <Globe className="w-4 h-4" />
                Domínio grátis por 1 ano incluso em todos os planos
              </p>
            </div>
          </div>

          {/* Features */}
          <div>
            <h4 className="font-semibold mb-4 flex items-center gap-2">
              <Check className="w-5 h-5 text-green-500" />
              O que está incluso:
            </h4>
            <div className="space-y-3">
              {plan.features.map((feature, i) => (
                <div
                  key={i}
                  className={`p-4 rounded-xl ${feature.included ? 'bg-white/5' : 'bg-white/5 opacity-50'}`}
                >
                  <div className="flex items-start gap-3">
                    {feature.included ? (
                      <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                    ) : (
                      <X className="w-5 h-5 text-gray-500 flex-shrink-0 mt-0.5" />
                    )}
                    <div>
                      <p className={`font-medium ${feature.included ? 'text-white' : 'text-gray-500'}`}>
                        {feature.text}
                      </p>
                      {feature.description && feature.included && (
                        <p className="text-sm text-gray-400 mt-1">{feature.description}</p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Monthly Fee Explanation */}
          <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/20 rounded-2xl p-6">
            <h4 className="font-semibold mb-4 flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-blue-400" />
              O que cobre a mensalidade?
            </h4>
            <div className="grid md:grid-cols-2 gap-4">
              {monthlyFeeDetails.map((item, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center flex-shrink-0">
                    <item.icon className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-medium text-sm">{item.title}</p>
                    <p className="text-xs text-gray-400">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-4 border-t border-white/10">
              <p className="text-sm text-gray-400">
                <span className="text-white font-medium">Importante:</span> O site fica em uso enquanto a mensalidade estiver sendo paga. 
                Você pode cancelar a qualquer momento <span className="text-green-400">sem multa</span>.
              </p>
              <p className="text-sm text-gray-400 mt-2">
                Caso queira o projeto permanente sem mensalidade e ficar responsável por ele, 
                <span className="text-white"> o valor é outro a ser negociado</span>.
              </p>
            </div>
          </div>

          {/* Delivery Info */}
          <div className="bg-white/5 rounded-xl p-4 flex items-start gap-3">
            <Clock className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-sm">Prazo de Entrega</p>
              <p className="text-sm text-gray-400">
                Até <span className="text-white font-medium">7 dias úteis</span>, mas pode ser muito mais rápido! 
                A entrega pode ser no mesmo dia ou no dia seguinte, dependendo da hora da contratação e da demanda atual.
              </p>
            </div>
          </div>

          {/* CTA */}
          <button className="w-full btn-primary py-4 rounded-full font-semibold flex items-center justify-center gap-2">
            Quero o Plano {plan.name}
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function Pricing() {
  const [isVisible, setIsVisible] = useState(false);
  const [hoveredPlan, setHoveredPlan] = useState<string | null>(null);
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const section = document.getElementById('planos');
    if (section) {
      observer.observe(section);
    }

    return () => observer.disconnect();
  }, []);

  const handlePlanClick = (plan: Plan) => {
    setSelectedPlan(plan);
    setIsDetailsOpen(true);
  };

  return (
    <section id="planos" className="py-24 relative bg-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className={`text-center mb-16 fade-in ${isVisible ? 'visible' : ''}`}>
          <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-4 py-2 mb-6">
            <Sparkles className="w-4 h-4 text-white" />
            <span className="text-sm text-gray-300">Planos e Preços</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="gradient-text">Invista no seu negócio</span>
            <br />
            <span className="text-white">sem quebrar o banco</span>
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Escolha o plano ideal para o seu estágio de crescimento. 
            Todos incluem site profissional + IA no WhatsApp + domínio grátis.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-6 lg:gap-8 mb-12">
          {plans.map((plan, index) => {
            const PlanIcon = plan.icon;
            return (
              <div
                key={plan.id}
                className={`pricing-card rounded-3xl p-6 lg:p-8 relative fade-in ${isVisible ? 'visible' : ''} ${
                  plan.popular ? 'featured' : ''
                }`}
                style={{ transitionDelay: `${index * 100}ms` }}
                onMouseEnter={() => setHoveredPlan(plan.id)}
                onMouseLeave={() => setHoveredPlan(null)}
              >
                {/* Badge */}
                {plan.badge && (
                  <div className={`absolute -top-3 left-1/2 transform -translate-x-1/2 px-4 py-1 rounded-full text-xs font-bold ${
                    plan.popular ? 'bg-white text-black' : 'bg-white/10 text-white'
                  }`}>
                    {plan.badge}
                  </div>
                )}

                {/* Plan Header */}
                <div className="text-center mb-6">
                  <div className={`w-12 h-12 rounded-full mx-auto mb-4 flex items-center justify-center ${
                    plan.popular ? 'bg-white text-black' : 'bg-white/10'
                  }`}>
                    <PlanIcon className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
                  <p className="text-sm text-gray-400 mb-4">{plan.description}</p>
                  <div className="flex flex-col items-center">
                    <span className="text-4xl font-bold">{plan.price}</span>
                    <span className="text-sm text-gray-500 mt-1">preço único</span>
                  </div>
                  <div className="mt-3 inline-flex items-center gap-1 text-sm text-green-400 bg-green-500/10 px-3 py-1 rounded-full">
                    <Globe className="w-4 h-4" />
                    Domínio grátis 1 ano
                  </div>
                  <p className="text-sm text-gray-400 mt-2">+ {plan.monthlyFee}</p>
                </div>

                {/* Features */}
                <ul className="space-y-3 mb-8">
                  {plan.features.slice(0, 5).map((feature, i) => (
                    <li key={i} className="flex items-start gap-3">
                      {feature.included ? (
                        <div className="w-5 h-5 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <Check className="w-3 h-3 text-green-400" />
                        </div>
                      ) : (
                        <div className="w-5 h-5 rounded-full bg-gray-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <X className="w-3 h-3 text-gray-500" />
                        </div>
                      )}
                      <span className={`text-sm ${feature.included ? 'text-gray-300' : 'text-gray-500'}`}>
                        {feature.text}
                      </span>
                    </li>
                  ))}
                  {plan.features.length > 5 && (
                    <li className="text-sm text-gray-500 text-center">
                      +{plan.features.length - 5} recursos
                    </li>
                  )}
                </ul>

                {/* CTA */}
                <button
                  onClick={() => handlePlanClick(plan)}
                  className={`w-full py-3 rounded-full font-semibold flex items-center justify-center gap-2 transition-all ${
                    plan.popular
                      ? 'btn-primary'
                      : 'btn-outline'
                  } ${hoveredPlan === plan.id ? 'scale-105' : ''}`}
                >
                  {plan.cta}
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Monthly Fee Info */}
        <div className={`fade-in ${isVisible ? 'visible' : ''}`}>
          <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/20 rounded-2xl p-6 max-w-3xl mx-auto">
            <h4 className="font-semibold mb-4 flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-blue-400" />
              O que está incluído na mensalidade?
            </h4>
            <div className="grid md:grid-cols-2 gap-4">
              {monthlyFeeDetails.map((item, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center flex-shrink-0">
                    <item.icon className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-medium text-sm">{item.title}</p>
                    <p className="text-xs text-gray-400">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-4 border-t border-white/10 text-center">
              <p className="text-sm text-gray-400">
                O site fica em uso enquanto a mensalidade estiver sendo paga. 
                <span className="text-green-400"> Cancele a qualquer momento sem multa.</span>
              </p>
            </div>
          </div>
        </div>

        {/* Guarantee */}
        <div className={`mt-12 text-center fade-in ${isVisible ? 'visible' : ''}`}>
          <div className="inline-flex items-center gap-3 bg-green-500/10 border border-green-500/20 rounded-2xl px-6 py-4">
            <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center">
              <Star className="w-6 h-6 text-green-400" />
            </div>
            <div className="text-left">
              <h4 className="font-semibold text-green-400">Garantia de 7 dias</h4>
              <p className="text-sm text-gray-400">Não gostou? Devolvemos 100% do seu dinheiro</p>
            </div>
          </div>
        </div>
      </div>

      {/* Plan Details Dialog */}
      <PlanDetailsDialog
        plan={selectedPlan}
        isOpen={isDetailsOpen}
        onClose={() => setIsDetailsOpen(false)}
      />
    </section>
  );
}
