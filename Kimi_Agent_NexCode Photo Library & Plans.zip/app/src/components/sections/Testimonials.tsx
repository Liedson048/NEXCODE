import { useEffect, useState } from 'react';
import { Star, Quote, ChevronLeft, ChevronRight } from 'lucide-react';

interface Testimonial {
  id: number;
  name: string;
  role: string;
  company: string;
  image: string;
  content: string;
  rating: number;
  results: string;
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: 'Maria Silva',
    role: 'Proprietária',
    company: 'Bella Estética',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face',
    content: 'A IA do WhatsApp mudou completamente meu negócio. Antes eu perdia muitos agendamentos porque não conseguia responder a todos. Agora a IA atende, qualifica e agenda automaticamente. Meu faturamento aumentou 40% em 3 meses!',
    rating: 5,
    results: '+40% faturamento',
  },
  {
    id: 2,
    name: 'João Santos',
    role: 'Diretor',
    company: 'Tech Imports',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
    content: 'O site ficou incrível e profissional. O que mais me impressionou foi a velocidade de entrega - em 7 dias estava tudo pronto e funcionando. O suporte é excelente, sempre respondem rápido.',
    rating: 5,
    results: '7 dias para entrega',
  },
  {
    id: 3,
    name: 'Ana Paula',
    role: 'Gerente',
    company: 'Padaria Real',
    image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face',
    content: 'Nossos clientes adoram poder fazer pedidos pelo WhatsApp a qualquer hora. A IA entende perfeitamente os pedidos e já manda o valor total. Reduziu em 70% o tempo que gastávamos no atendimento.',
    rating: 5,
    results: '-70% tempo de atendimento',
  },
  {
    id: 4,
    name: 'Carlos Mendes',
    role: 'Médico',
    company: 'Clínica Vida',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
    content: 'Como médico, não tenho tempo para gerenciar agendamentos. A IA da NexCode faz tudo automaticamente - agenda consultas, envia lembretes e até faz pré-atendimento. Minha secretária agora foca em tarefas mais importantes.',
    rating: 5,
    results: '100% automação',
  },
  {
    id: 5,
    name: 'Fernanda Lima',
    role: 'Proprietária',
    company: 'Mecânica Silva',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=face',
    content: 'Nunca imaginei que uma mecânica precisava de site, mas depois que fizemos com a NexCode, começamos a receber muito mais orçamentos. A IA tira dúvidas dos clientes sobre preços e serviços 24h por dia.',
    rating: 5,
    results: '+3x orçamentos',
  },
];

export function Testimonials() {
  const [isVisible, setIsVisible] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [autoplay, setAutoplay] = useState(true);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const section = document.getElementById('depoimentos');
    if (section) {
      observer.observe(section);
    }

    return () => observer.disconnect();
  }, []);

  // Autoplay
  useEffect(() => {
    if (!autoplay) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [autoplay]);

  const goToPrevious = () => {
    setAutoplay(false);
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const goToNext = () => {
    setAutoplay(false);
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const currentTestimonial = testimonials[currentIndex];

  return (
    <section id="depoimentos" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className={`text-center mb-16 fade-in ${isVisible ? 'visible' : ''}`}>
          <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-4 py-2 mb-6">
            <Quote className="w-4 h-4 text-white" />
            <span className="text-sm text-gray-300">Depoimentos</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="gradient-text">O que nossos clientes</span>
            <br />
            <span className="text-white">dizem sobre nós</span>
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Já ajudamos mais de 200 empresas a transformarem sua presença digital.
            Veja o que eles acharam:
          </p>
        </div>

        {/* Main Testimonial */}
        <div className={`fade-in ${isVisible ? 'visible' : ''}`}>
          <div className="max-w-4xl mx-auto">
            <div className="relative bg-white/5 border border-white/10 rounded-3xl p-8 md:p-12">
              {/* Quote Icon */}
              <div className="absolute -top-6 left-8 w-12 h-12 rounded-full bg-white flex items-center justify-center">
                <Quote className="w-6 h-6 text-black" />
              </div>

              {/* Content */}
              <div className="text-center">
                {/* Rating */}
                <div className="flex justify-center gap-1 mb-6">
                  {[...Array(currentTestimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>

                {/* Quote */}
                <p className="text-xl md:text-2xl text-gray-300 leading-relaxed mb-8">
                  "{currentTestimonial.content}"
                </p>

                {/* Author */}
                <div className="flex flex-col items-center">
                  <img
                    src={currentTestimonial.image}
                    alt={currentTestimonial.name}
                    className="w-16 h-16 rounded-full object-cover mb-4 border-2 border-white/20"
                  />
                  <h4 className="font-semibold text-white">{currentTestimonial.name}</h4>
                  <p className="text-sm text-gray-400">{currentTestimonial.role}</p>
                  <p className="text-sm text-gray-500">{currentTestimonial.company}</p>
                  
                  {/* Result Badge */}
                  <div className="mt-4 inline-flex items-center gap-2 bg-green-500/10 border border-green-500/20 rounded-full px-4 py-2">
                    <span className="text-green-400 text-sm font-semibold">{currentTestimonial.results}</span>
                  </div>
                </div>
              </div>

              {/* Navigation */}
              <div className="flex justify-center gap-4 mt-8">
                <button
                  onClick={goToPrevious}
                  className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                
                {/* Dots */}
                <div className="flex items-center gap-2">
                  {testimonials.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => {
                        setAutoplay(false);
                        setCurrentIndex(index);
                      }}
                      className={`w-2 h-2 rounded-full transition-all ${
                        index === currentIndex ? 'bg-white w-6' : 'bg-white/30'
                      }`}
                    />
                  ))}
                </div>

                <button
                  onClick={goToNext}
                  className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Client Logos */}
        <div className={`mt-16 fade-in ${isVisible ? 'visible' : ''}`}>
          <p className="text-center text-sm text-gray-500 mb-8">Empresas que confiam na NexCode</p>
          <div className="flex flex-wrap justify-center gap-8 md:gap-12 opacity-50">
            {['Bella Estética', 'Tech Imports', 'Padaria Real', 'Clínica Vida', 'Mecânica Silva', 'FitLife'].map((brand) => (
              <span key={brand} className="text-lg font-semibold text-gray-400">{brand}</span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
