import { useEffect, useState } from 'react';
import { X, Check, Globe, Bot, Bell, TrendingUp, Users, Clock, Shield, Globe2 } from 'lucide-react';

export function ProblemSolution() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const section = document.getElementById('como-funciona');
    if (section) {
      observer.observe(section);
    }

    return () => observer.disconnect();
  }, []);

  const problems = [
    {
      icon: X,
      title: 'Site desatualizado ou inexistente',
      description: 'Clientes não te encontram no Google',
    },
    {
      icon: X,
      title: 'Demora para responder clientes',
      description: 'Eles compram do concorrente que responde primeiro',
    },
    {
      icon: X,
      title: 'Sem tempo para organizar atendimento',
      description: 'Mensagens perdidas, agendamentos esquecidos',
    },
  ];

  const solutions = [
    {
      icon: Globe,
      title: 'Site Profissional',
      description: 'Design moderno, responsivo e otimizado para Google',
    },
    {
      icon: Bot,
      title: 'IA no WhatsApp',
      description: 'Atende, qualifica e agenda automaticamente 24h',
    },
    {
      icon: Bell,
      title: 'Notificações Inteligentes',
      description: 'Você recebe alertas apenas quando precisa agir',
    },
  ];

  const stats = [
    { value: '78%', label: 'dos brasileiros preferem WhatsApp', icon: Users },
    { value: '24h', label: 'de atendimento automático', icon: Clock },
    { value: '3x', label: 'mais conversões com IA', icon: TrendingUp },
  ];

  const benefits = [
    { icon: Shield, text: 'Garantia de 7 dias' },
    { icon: Clock, text: 'Até 7 dias úteis de entrega' },
    { icon: Globe2, text: 'Domínio grátis 1 ano' },
  ];

  return (
    <section id="como-funciona" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Stats Bar */}
        <div className={`grid grid-cols-3 gap-4 mb-20 fade-in ${isVisible ? 'visible' : ''}`}>
          {stats.map((stat, index) => (
            <div
              key={index}
              className="bg-white/5 border border-white/10 rounded-2xl p-6 text-center"
            >
              <stat.icon className="w-8 h-8 mx-auto mb-3 text-white/60" />
              <div className="text-3xl md:text-4xl font-bold gradient-text mb-1">{stat.value}</div>
              <div className="text-xs md:text-sm text-gray-400">{stat.label}</div>
            </div>
          ))}
        </div>

        <div className="grid md:grid-cols-2 gap-16 items-center">
          {/* Problem Side */}
          <div className={`fade-in ${isVisible ? 'visible' : ''}`}>
            <div className="inline-flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-full px-4 py-2 mb-6">
              <X className="w-4 h-4 text-red-400" />
              <span className="text-sm text-red-400">O Problema</span>
            </div>
            
            <h2 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
              Seu cliente está no WhatsApp.
              <br />
              <span className="text-gray-500">E você, está?</span>
            </h2>
            
            <p className="text-lg text-gray-400 mb-8 leading-relaxed">
              78% dos brasileiros preferem falar com empresas pelo WhatsApp.
              Mas responder manualmente todos os dias é impossível.
              Enquanto isso, você perde vendas.
            </p>

            <div className="space-y-4">
              {problems.map((problem, index) => (
                <div
                  key={index}
                  className="flex items-start gap-4 p-4 bg-red-500/5 border border-red-500/10 rounded-xl"
                >
                  <div className="w-8 h-8 rounded-full bg-red-500/20 flex items-center justify-center flex-shrink-0">
                    <problem.icon className="w-4 h-4 text-red-400" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white">{problem.title}</h4>
                    <p className="text-gray-500 text-sm">{problem.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Solution Side */}
          <div className={`fade-in ${isVisible ? 'visible' : ''}`} style={{ transitionDelay: '200ms' }}>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-white/10 to-transparent rounded-3xl blur-2xl"></div>
              <div className="relative bg-white/5 border border-white/10 rounded-3xl p-8 backdrop-blur-sm">
                <div className="inline-flex items-center gap-2 bg-green-500/10 border border-green-500/20 rounded-full px-4 py-2 mb-6">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-sm text-green-400">A Solução</span>
                </div>

                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-white to-gray-300 flex items-center justify-center">
                    <span className="text-black font-bold text-xl">N</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">NexCode</h3>
                    <p className="text-gray-400 text-sm">Tudo integrado, automático e profissional</p>
                  </div>
                </div>

                <div className="space-y-4">
                  {solutions.map((solution, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-4 p-4 bg-white/5 rounded-xl border border-white/5 hover:border-white/20 transition-colors"
                    >
                      <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center">
                        <solution.icon className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-semibold">{solution.title}</h4>
                        <p className="text-sm text-gray-400">{solution.description}</p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Benefits */}
                <div className="mt-6 pt-6 border-t border-white/10">
                  <div className="flex flex-wrap gap-3">
                    {benefits.map((benefit, i) => (
                      <div key={i} className="flex items-center gap-2 text-sm text-gray-400">
                        <benefit.icon className="w-4 h-4 text-green-400" />
                        <span>{benefit.text}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Price */}
                <div className="mt-6 pt-6 border-t border-white/10">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Investimento inicial</span>
                    <span className="font-bold text-white text-2xl">R$ 299,99</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">+ mensalidade a partir de R$ 99,99</p>
                  <p className="text-xs text-green-400 mt-1">✓ Domínio grátis por 1 ano</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
