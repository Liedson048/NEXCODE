import { useEffect, useState } from 'react';
import { ChevronDown, HelpCircle, MessageCircle, Clock, Globe, Shield, Zap } from 'lucide-react';

interface FAQItem {
  question: string;
  answer: string;
  icon?: React.ElementType;
}

const faqs: FAQItem[] = [
  {
    question: 'Quanto tempo leva para meu site ficar pronto?',
    answer: 'Nosso prazo máximo é de 7 dias úteis após a confirmação do pagamento e envio de todos os materiais necessários (logo, fotos, textos, etc.). Porém, muitas vezes conseguimos entregar muito mais rápido - pode ser no mesmo dia ou no dia seguinte, dependendo da hora da contratação e da demanda atual. Assim que confirmarmos seu pedido, daremos uma estimativa mais precisa.',
    icon: Clock,
  },
  {
    question: 'O que está incluído na mensalidade?',
    answer: 'A mensalidade cobre: (1) Manutenções futuras - atualizações de segurança, correções de bugs e melhorias contínuas; (2) Ajustes e alterações - pequenas mudanças de texto, fotos e informações quando precisar; (3) Suporte via WhatsApp - tire dúvidas e receba ajuda sempre que precisar; (4) Hospedagem e domínio - seu site sempre online com servidor de alta performance. O site fica em uso enquanto a mensalidade estiver sendo paga.',
    icon: Shield,
  },
  {
    question: 'Posso cancelar a qualquer momento?',
    answer: 'Sim! Você pode cancelar a qualquer momento sem multa nem taxa de cancelamento. O site permanece ativo até o final do período pago. Se quiser retomar depois, é só voltar a pagar a mensalidade.',
    icon: Zap,
  },
  {
    question: 'E se eu quiser o projeto sem mensalidade?',
    answer: 'É possível! Caso queira o projeto permanente sem precisar pagar mensalidade e ficar você mesmo responsável pela manutenção e hospedagem, o valor é outro e deve ser negociado. Entre em contato conosco para discutirmos essa opção.',
    icon: Globe,
  },
  {
    question: 'Como funciona a IA do WhatsApp?',
    answer: 'Nossa IA é treinada especificamente para o seu negócio. Ela responde automaticamente às mensagens no WhatsApp, tira dúvidas frequentes, qualifica leads, agenda horários e envia lembretes. Você recebe notificações apenas quando um cliente precisa de atenção humana ou quando um agendamento é confirmado. Funciona 24h por dia, 7 dias por semana.',
    icon: MessageCircle,
  },
  {
    question: 'O domínio realmente é grátis?',
    answer: 'Sim! Todos os planos incluem domínio .com.br grátis por 1 ano. Após esse período, a renovação custa cerca de R$ 40-50 por ano (valor cobrado pelo registro.br). Você pode usar um domínio que já possui ou registrar um novo.',
    icon: Globe,
  },
  {
    question: 'Preciso pagar alguma taxa de setup?',
    answer: 'Não! O valor do plano é único e já inclui toda a configuração inicial do site e da IA. Não cobramos taxa de setup nem taxa de instalação.',
    icon: Shield,
  },
  {
    question: 'Posso personalizar o template escolhido?',
    answer: 'Sim! Todos os templates podem ser personalizados com suas cores, logo, fotos e textos. No plano Pro, a personalização é mais completa. No plano Premium, criamos um design único do zero exclusivamente para sua marca.',
    icon: Zap,
  },
  {
    question: 'E se eu não gostar do resultado?',
    answer: 'Você tem 7 dias de garantia incondicional. Se não estiver satisfeito com o resultado, devolvemos 100% do seu dinheiro, sem perguntas. Sua satisfação é nossa prioridade.',
    icon: Shield,
  },
  {
    question: 'O site funciona em celulares?',
    answer: 'Sim! Todos os nossos sites são 100% responsivos, ou seja, se adaptam perfeitamente a qualquer dispositivo: computadores, tablets e smartphones. Mais de 70% dos acessos hoje vêm de celulares, então essa é uma prioridade absoluta.',
    icon: Globe,
  },
  {
    question: 'Como faço para atualizar meu site depois?',
    answer: 'Você recebe acesso a um painel administrativo intuitivo onde pode editar textos, fotos, preços e horários. Para mudanças maiores de estrutura, nosso suporte está disponível via WhatsApp. No plano Premium, incluímos atualizações ilimitadas.',
    icon: Zap,
  },
  {
    question: 'Como entro em contato com o suporte?',
    answer: 'Oferecemos suporte por WhatsApp em todos os planos. No plano Basic, o atendimento é em horário comercial. No plano Pro, você tem suporte prioritário. No plano Premium, suporte 24/7 dedicado. Nosso horário de atendimento é de segunda a sexta, 9h às 18h, exceto no plano Premium que é 24 horas.',
    icon: MessageCircle,
  },
];

export function FAQ() {
  const [isVisible, setIsVisible] = useState(false);
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const section = document.getElementById('faq');
    if (section) {
      observer.observe(section);
    }

    return () => observer.disconnect();
  }, []);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-24 relative bg-white/5">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className={`text-center mb-16 fade-in ${isVisible ? 'visible' : ''}`}>
          <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-4 py-2 mb-6">
            <HelpCircle className="w-4 h-4 text-white" />
            <span className="text-sm text-gray-300">Dúvidas Frequentes</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="gradient-text">Tire suas dúvidas</span>
          </h2>
          <p className="text-lg text-gray-400">
            Ainda tem perguntas? Nosso time está pronto para ajudar.
          </p>
        </div>

        {/* FAQ List */}
        <div className={`space-y-4 fade-in ${isVisible ? 'visible' : ''}`}>
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden"
            >
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full flex items-center justify-between p-5 text-left hover:bg-white/5 transition-colors"
              >
                <div className="flex items-center gap-3">
                  {faq.icon && <faq.icon className="w-5 h-5 text-gray-400 flex-shrink-0" />}
                  <span className="font-semibold text-white pr-4">{faq.question}</span>
                </div>
                <ChevronDown
                  className={`w-5 h-5 flex-shrink-0 transition-transform ${
                    openIndex === index ? 'rotate-180' : ''
                  }`}
                />
              </button>
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  openIndex === index ? 'max-h-96' : 'max-h-0'
                }`}
              >
                <div className="px-5 pb-5 text-gray-400 leading-relaxed">
                  {faq.answer}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Contact CTA */}
        <div className={`mt-12 text-center fade-in ${isVisible ? 'visible' : ''}`}>
          <p className="text-gray-400 mb-4">Não encontrou sua resposta?</p>
          <a
            href="https://wa.me/5511999999999"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary px-6 py-3 rounded-full font-semibold inline-flex items-center gap-2"
          >
            <MessageCircle className="w-5 h-5" />
            Falar com Especialista
          </a>
        </div>
      </div>
    </section>
  );
}
