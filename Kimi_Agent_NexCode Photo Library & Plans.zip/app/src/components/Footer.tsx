import { 
  MessageCircle, 
  Mail, 
  Phone, 
  MapPin, 
  Instagram, 
  Linkedin, 
  Facebook,
  ArrowRight,
  Sparkles
} from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    produto: [
      { label: 'Templates', href: '#templates' },
      { label: 'Planos', href: '#planos' },
      { label: 'Como Funciona', href: '#como-funciona' },
      { label: 'Depoimentos', href: '#depoimentos' },
    ],
    suporte: [
      { label: 'FAQ', href: '#faq' },
      { label: 'Central de Ajuda', href: '#' },
      { label: 'Contato', href: '#' },
      { label: 'Status', href: '#' },
    ],
    empresa: [
      { label: 'Sobre Nós', href: '#' },
      { label: 'Blog', href: '#' },
      { label: 'Carreiras', href: '#' },
      { label: 'Parceiros', href: '#' },
    ],
    legal: [
      { label: 'Termos de Uso', href: '#' },
      { label: 'Política de Privacidade', href: '#' },
      { label: 'LGPD', href: '#' },
    ],
  };

  return (
    <footer className="bg-black border-t border-white/10">
      {/* CTA Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="bg-gradient-to-r from-white/10 to-white/5 border border-white/10 rounded-3xl p-8 md:p-12 text-center">
          <div className="inline-flex items-center gap-2 bg-white/10 rounded-full px-4 py-2 mb-6">
            <Sparkles className="w-4 h-4" />
            <span className="text-sm">Pronto para começar?</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Transforme seu negócio hoje
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto mb-8">
            Junte-se a mais de 200 empresas que já estão vendendo mais com a NexCode.
            Seu site profissional + IA no WhatsApp esperam por você.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#planos"
              className="btn-primary px-8 py-4 rounded-full font-semibold inline-flex items-center justify-center gap-2"
            >
              Ver Planos
              <ArrowRight className="w-5 h-5" />
            </a>
            <a
              href="https://wa.me/5511999999999"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-outline px-8 py-4 rounded-full font-semibold inline-flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-5 h-5" />
              Falar no WhatsApp
            </a>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-6 gap-8">
          {/* Brand */}
          <div className="col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 relative logo-glow">
                <svg viewBox="0 0 100 100" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <linearGradient id="footerLogoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" style={{ stopColor: '#ffffff', stopOpacity: 1 }} />
                      <stop offset="100%" style={{ stopColor: '#a0a0a0', stopOpacity: 1 }} />
                    </linearGradient>
                  </defs>
                  <path d="M20 80 L20 20 L35 20 L65 60 L65 20 L80 20 L80 80 L65 80 L35 40 L35 80 Z" fill="url(#footerLogoGradient)"/>
                </svg>
              </div>
              <span className="text-2xl font-bold">NexCode</span>
            </div>
            <p className="text-gray-400 text-sm mb-6 max-w-xs">
              Sites profissionais + IA no WhatsApp para pequenos negócios crescerem online.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-semibold mb-4">Produto</h4>
            <ul className="space-y-2">
              {footerLinks.produto.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-sm text-gray-400 hover:text-white transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Suporte</h4>
            <ul className="space-y-2">
              {footerLinks.suporte.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-sm text-gray-400 hover:text-white transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Empresa</h4>
            <ul className="space-y-2">
              {footerLinks.empresa.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-sm text-gray-400 hover:text-white transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Legal</h4>
            <ul className="space-y-2">
              {footerLinks.legal.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-sm text-gray-400 hover:text-white transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Contact Info */}
        <div className="mt-12 pt-8 border-t border-white/10">
          <div className="flex flex-wrap gap-6 justify-center md:justify-start">
            <a href="mailto:contato@nexcode.com.br" className="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors">
              <Mail className="w-4 h-4" />
              contato@nexcode.com.br
            </a>
            <a href="tel:+5511999999999" className="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors">
              <Phone className="w-4 h-4" />
              (11) 99999-9999
            </a>
            <span className="flex items-center gap-2 text-sm text-gray-400">
              <MapPin className="w-4 h-4" />
              São Paulo, SP - Brasil
            </span>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-8 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-gray-500">
            © {currentYear} NexCode. Todos os direitos reservados.
          </p>
          <p className="text-sm text-gray-500">
            Feito com ❤️ no Brasil
          </p>
        </div>
      </div>
    </footer>
  );
}
