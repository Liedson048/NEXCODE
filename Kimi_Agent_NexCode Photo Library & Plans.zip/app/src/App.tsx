import { Navigation } from './components/Navigation';
import { Hero } from './components/sections/Hero';
import { ProblemSolution } from './components/sections/ProblemSolution';
import { TemplateGallery } from './components/sections/TemplateGallery';
import { PlanRecommender } from './components/sections/PlanRecommender';
import { Pricing } from './components/sections/Pricing';
import { Testimonials } from './components/sections/Testimonials';
import { FAQ } from './components/sections/FAQ';
import { Footer } from './components/Footer';
import { FloatingChatbot } from './components/chatbot/FloatingChatbot';
import { SocialProofToast } from './components/SocialProofToast';

function App() {
  return (
    <div className="bg-black text-white min-h-screen">
      <Navigation />
      
      <main>
        <Hero />
        <ProblemSolution />
        <TemplateGallery />
        <PlanRecommender />
        <Pricing />
        <Testimonials />
        <FAQ />
      </main>
      
      <Footer />
      
      {/* Floating Elements */}
      <FloatingChatbot />
      <SocialProofToast />
    </div>
  );
}

export default App;
